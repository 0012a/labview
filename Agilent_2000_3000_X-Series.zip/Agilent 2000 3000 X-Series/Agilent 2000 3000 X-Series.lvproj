﻿<?xml version='1.0' encoding='UTF-8'?>
<Project Type="Project" LVVersion="23008000">
	<Property Name="Instrument Driver" Type="Str">True</Property>
	<Property Name="NI.Project.Description" Type="Str">This project is used by developers to edit API and example files for LabVIEW Plug and Play instrument drivers.</Property>
	<Item Name="My Computer" Type="My Computer">
		<Property Name="CCSymbols" Type="Str">OS,Win;CPU,x86;</Property>
		<Property Name="NI.SortType" Type="Int">3</Property>
		<Property Name="specify.custom.address" Type="Bool">false</Property>
		<Item Name="Examples" Type="Folder">
			<Item Name="Agilent 2000 3000 X-Series Acquire Digital Voltmeter.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Acquire Digital Voltmeter.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Acquire Multiple Waveforms.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Acquire Multiple Waveforms.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Acquire Waveform Continuously.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Acquire Waveform Continuously.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Acquire Waveform.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Acquire Waveform.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Edge Triggered Acquisition.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Edge Triggered Acquisition.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Frequency Response Analysis.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Frequency Response Analysis.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Harmonics Power Analysis.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Harmonics Power Analysis.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Ripple Power Analysis.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Ripple Power Analysis.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Transfer Current Waveform.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Transfer Current Waveform.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Waveform Generator.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Waveform Generator.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Clock Recovery Jitter Measurement.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Clock Recovery Jitter Measurement.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Jitter Analysis Histogram.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Jitter Analysis Histogram.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Real Time Eye.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Real Time Eye.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Adjacent Channel Power Ratio.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Adjacent Channel Power Ratio.vi"/>
			<Item Name="Agilent 2000 3000 X-Series Control Loop Response Analysis.vi" Type="VI" URL="../Examples/Agilent 2000 3000 X-Series Control Loop Response Analysis.vi"/>
			<Item Name="Agilent 2000 3000 X-Series.bin3" Type="Document" URL="/&lt;instrlib&gt;/Agilent 2000 3000 X-Series/Examples/Agilent 2000 3000 X-Series.bin3"/>
		</Item>
		<Item Name="Agilent 2000 3000 X-Series.lvlib" Type="Library" URL="../Agilent 2000 3000 X-Series.lvlib"/>
		<Item Name="Dependencies" Type="Dependencies"/>
		<Item Name="Build Specifications" Type="Build"/>
	</Item>
</Project>
